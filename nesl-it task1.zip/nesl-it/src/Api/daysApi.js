const daysapi = [
  {
    id: 1,
    day: 'Monday',
    nameOpen: 'monOpen',
    nameClosed: 'monClosed',
  },
  {
    id: 2,
    day: 'Tuesday',
    nameOpen: 'tuesOpen',
    nameClosed: 'tuesClosed',
  },
  {
    id: 3,
    day: 'Wednesday',
    nameOpen: 'wedOpen',
    nameClosed: 'wedClosed',
  },
  {
    id: 4,
    day: 'Thursday',
    nameOpen: 'thursOpen',
    nameClosed: 'thursClosed',
  },
  {
    id: 5,
    day: 'Friday',
    nameOpen: 'friOpen',
    nameClosed: 'friClosed',
  },
  {
    id: 6,
    day: 'Saturday',
    nameOpen: 'satOpen',
    nameClosed: 'satClosed',
  },
  {
    id: 7,
    day: 'Sunday',
    sunOpen: 'sunOpen',
    sunClosed: 'sunClosed',
  },
];

export default daysapi;

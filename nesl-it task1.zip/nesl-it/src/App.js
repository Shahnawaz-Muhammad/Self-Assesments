import React from 'react';
// import HeroImg from './heroImg';
import Main from './Main';
import Navbar from './navbar';

const App = () => {
  return (
    <>
      <Navbar />
      {/* <HeroImg /> */}
      <Main />
    </>
  );
};

export default App;

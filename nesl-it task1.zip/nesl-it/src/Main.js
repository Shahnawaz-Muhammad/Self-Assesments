import React, { useState } from 'react';
import daysapi from './Api/daysApi';

const Main = () => {
  const [userInput, setUserInput] = useState(daysapi);
  return (
    <>
      <section className='main-container'>
        <div className='container-fluid'>
          <div className='container-hero'>
            <img src='./images/heroImg.jpg ' alt='heroImg' />
          </div>
          <div className='container container-header'>
            <h1 className='main-heading'>List your name</h1>
            <h2 className='main-sub-heading'>2. Venue Opening Times</h2>
            <div className='alert alert-success alert-box ms-auto' role='alert'>
              <p className='alert-text'>
                <span className='alert-hint'>Hint: </span>Aww yeah, you
                successfully read this important alert message. This example
                text is going to run a bit longer so that you can see how
                spacing within an alert works with this kind of content.
              </p>
            </div>
            <div className='container venue-container'>
              <h2 className='main-sub-heading venue-heading'>
                Click on the day to Open/Closed
              </h2>
            </div>
            <div className='days-container'>
              <div className='container'>
                {daysapi.map((curElem) => {
                  const { id, day, nameOpen, nameClosed } = curElem;
                  return (
                    <>
                      <div className='row days-main-row' key={id}>
                        <div className='col-12 col-lg-4'>
                          <button className='btn btn-light btn-style'>
                            {' '}
                            {day}
                          </button>
                        </div>
                        <div className='col-12 col-lg-8 days-input-container'>
                          <div className='row'>
                            <div className='col-12 col-lg-6 days-input'>
                              <input
                                type='text'
                                className='input-field'
                                name={nameOpen}
                              />
                              <i class='fas fa-history time-icon'></i>
                            </div>
                            <div className='col-12 col-lg-6 days-input'>
                              <input
                                type='text'
                                className='input-field'
                                name={nameClosed}
                              />
                              <i class='fas fa-history time-icon'></i>
                            </div>
                          </div>
                        </div>
                      </div>
                    </>
                  );
                })}
              </div>
              <div className='container-button'>
                <button className='btn btn-light btn-style btn-style-submit '>
                  {' '}
                  Submit
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default Main;
